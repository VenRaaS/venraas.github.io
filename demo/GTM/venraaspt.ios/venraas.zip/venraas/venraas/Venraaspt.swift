//
//  Venraaspt.swift
//  venraas
//
//  Created by Charlie Liao on 2019/11/26.
//  Copyright © 2019 ITRI. All rights reserved.
//

import Foundation

class Venraaspt: NSObject {
    static let mInstance = Venraaspt()

    //let serverLog = "apid.venraas.tw"
    //let serverLog = "apid.friday.tw"
    let apiUuid = "/venapis/vengu"
    let apiLog = "/venapis/log"
    //let serverHermes = "apih.venraas.tw"
    //let serverHermes = "apih.friday.tw"
    let apiHermes = "/hermes/api/goods/rank"

    var serverLog = ""
    var serverHermes = ""
    
    var token = ""
    var domain = ""
    var clientHost = ""
    var topHost = ""
    var venGuid = ""
    var venSession = ""

    var userId = ""
    var action = ""
    var pageType = ""
    var categoryCode = ""
    var goodsId = ""
    var transI = ""
    var nowRec = ""
    var fromRec = ""
    var device = "mbe"
    var keyword = ""

    var jGoods = ""

    private override init() {
        print("init...")
    }
    
    deinit {
        print("deinit...")
    }

    /**
     Venraaspt 使用前必須先呼叫ven_init設定必需的參數
     
     :param: _serverLog  weblog server domain
     :param: _serverHermes  recomd server domain
     :param: _token  電商的token
     :param: _domain  電商的domain
     :param: _clientHost
     :param: _topHost
     :param: _venGuid  使用者的guid(null或""將會由server產生)

     */
    func ven_init(serverLog: String, serverHermes: String, token: String, domain: String, clientHost: String, topHost: String, venGuid: String?) {
        Log(msg: "[ven_init] serverLog='" + serverLog + "', serverHermes='" + serverHermes + "', token='" + token + "', domain='" + domain + "'")
        self.serverLog = serverLog
        self.serverHermes = serverHermes
        self.token = token
        self.domain = domain
        self.clientHost = clientHost
        self.topHost = topHost

        if ((venGuid == nil) || (venGuid == "")) {
            self.venGuid = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=g&pt=a")
        }
        else {
            self.venGuid = venGuid!
        }
        Log(msg: "[ven_init] venGuid='\(self.venGuid)'")
        venSession = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=s&pt=a")
        Log(msg: "[ven_init] venSession='\(self.venSession)'")
    }

    /**
     讀取使用者的guid

     :return: 使用者的guid(venGuid)
     
     */
    func ven_getVenGuid() -> String {
        return self.venGuid;
    }

    /**
     * 設定使用者的帳號
     *
     * @param userId  使用者的帳號
     *
     */
    func ven_uid(userId: String) {
        self.userId = userId;
    }

    /**
     讀取使用者的帳號

     :return: userId  使用者的帳號

     */
    func ven_getUid() -> String {
        return self.userId;
    }

    /**
     webLog for portal(首頁)

     */
    func ven_portal() {
        ven_clear()
        ven_log(_action: "pageload", _pageType: "p")
    }

    /**
     webLog for eDM(廣告頁)

     */
    func ven_edm() {
        ven_clear()
        ven_log(_action: "pageload", _pageType: "edm")
    }

    /**
     webLog for search(搜尋頁)

     ：:param: keyword 搜尋字串

     */
    func ven_search(keyword: String) {
        ven_clear()
        self.keyword = keyword
        ven_log(_action: "pageload", _pageType: "sep")
    }

    /**
     webLog for category(分類頁)

     :param: categoryCode 分類頁代碼

     */
    func ven_category(categoryCode: String) {
        ven_clear()
        self.categoryCode = categoryCode
        ven_log(_action: "pageload", _pageType: "cap")
    }

    /**
     webLog for goods(商品頁)

     :param: categoryCode 分類頁代碼
     :param: goodsId 商品代碼
     :param: keyword 搜尋字串
     :param: fromRec 來源推薦方式代碼
     :param: nowRec 推薦方式代碼

     */
    func ven_goods(categoryCode: String, goodsId: String, keyword: String, fromRec: String,  nowRec: String) {
        ven_clear()
        self.categoryCode = categoryCode
        self.goodsId = goodsId
        self.keyword = keyword
        self.fromRec = fromRec
        self.nowRec = nowRec
        ven_log(_action: "pageload", _pageType: "gop")
    }

    /**
     webLog for cart(購物車頁)

     :param: transI 購物車資訊

     */
    func ven_cart(transI: String) {
        ven_clear()
        self.transI = transI
        ven_log(_action: "cartload", _pageType: "scp")
    }

    /**
     webLog for order(結帳頁)

     :param: transI 結帳資訊

     */
    func ven_order(transI: String) {
        ven_clear()
        self.transI = transI
        ven_log(_action: "checkout", _pageType: "orp")
    }

    /**
     webLog for user define

     :param: _action pageload, cartload, checkout, cartadd, reccall
     :param: _pageType p, edm, sep, cap, gop, scp, orp...

     */
    func ven_log(_action: String, _pageType: String) {
        self.action = _action
        self.pageType = _pageType

        Log(msg: "[ven_log] venGuid='" + venGuid + "'")
        if check_venGuid() == false {
            venGuid = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=g&pt=a")
            Log(msg: "[ven_log] venGuid='\(self.venGuid)'")
        }
        Log(msg: "[ven_log] venSession='" + venSession + "'")
        if check_venSession() == false {
            venSession = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=s&pt=a")
            Log(msg: "[ven_log] venSession='\(self.venSession)'")
        }

        let tick: Int64 = Int64((Date().timeIntervalSince1970 * 1000).rounded())
        let zoneOffset = TimeZone.current.secondsFromGMT()
        
        var params = ""
        params = action + "={"
                + "\"token\":\"" + token + "\""
                + ",\"page_type\":\"" + pageType + "\""
                + ",\"action\":\"" + action + "\""
                + ",\"client_host\":\"" + clientHost + "\""
                + ",\"tophost\":\"" + topHost + "\""
                + "\",\"device\":\"" + device + "\""
                + ",\"client_utc\":" + String(tick)
                + ",\"client_tzo\":" + String(zoneOffset)

        if (userId.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"uid\":\"" + userId + "\""
        }
        else {
            params += ",\"uid\":null"
        }
        if (categoryCode.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"categ_code\":\"" + categoryCode + "\""
        }
        else {
            params += ",\"categ_code\":null"
        }
        if (goodsId.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"gid\":\"" + goodsId + "\""
        }
        else {
            params += ",\"gid\":null"
        }
        if (transI.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"trans_i\":\"" + transI + "\""
        }
        else {
            params += ",\"trans_i\":null"
        }
        if (nowRec.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"now_rec\":\"" + nowRec + "\""
        }
        else {
            params += ",\"now_rec\":null"
        }
        if (fromRec.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"from_rec\":\"" + fromRec + "\""
        }
        else {
            params += ",\"from_rec\":null"
        }
        if (venGuid.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"ven_guid\":\"" + venGuid + "\""
        }
        else {
            params += ",\"ven_guid\":null"
        }
        if (venSession.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"ven_session\":\"" + venSession + "\""
        }
        else {
            params += ",\"ven_session\":null"
        }
        if (keyword.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"keyword\":\"" + keyword + "\""
        }
        else {
            params += ",\"keyword\":null"
        }
        params += "\"}"
        let Params = params.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        if (Params != nil) {
            params = Params!
        }
        
        httpPost(url: "https://" + serverLog + apiLog,
                 contentType: "application/x-www-form-urlencoded;charset=UTF-8",
                 postData: params) { (results) in
            if let response = results.response {
                self.Log(msg: "[ven_log] httpStatusCode='\(response.httpStatusCode)'")
            }
            if let data = results.data {
                self.Log(msg: "[ven_log] data='\(String(decoding: data, as: UTF8.self))'")
            }
        }
    }

    /**
     webLog for 商品放入購物車時呼叫

     :param: _goodsId 商品代碼

     */
    func ven_cartAdd(_goodsId: String) {
        self.goodsId = _goodsId

        Log(msg: "[ven_cartAdd] venGuid='" + venGuid + "'")
        if check_venGuid() == false {
            venGuid = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=g&pt=a")
            Log(msg: "[ven_cartAdd] venGuid='\(self.venGuid)'")
        }
        Log(msg: "[ven_cartAdd] venSession='" + venSession + "'")
        if check_venSession() == false {
            venSession = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=s&pt=a")
            Log(msg: "[ven_cartAdd] venSession='\(self.venSession)'")
        }

        let tick: Int64 = Int64((Date().timeIntervalSince1970 * 1000).rounded())
        let zoneOffset = TimeZone.current.secondsFromGMT()
        
        var params = ""
        params = "cartadd={"
                + "\"token\":\"" + token + "\""
                + ",\"page_type\":\"" + pageType + "\""
                + ",\"action\":\"cartadd\""
                + ",\"client_host\":\"" + clientHost + "\""
                + ",\"tophost\":\"" + topHost + "\""
                + "\",\"device\":\"" + device + "\""
                + ",\"client_utc\":" + String(tick)
                + ",\"client_tzo\":" + String(zoneOffset)

        if (userId.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"uid\":\"" + userId + "\""
        }
        else {
            params += ",\"uid\":null"
        }
        if (categoryCode.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"categ_code\":\"" + categoryCode + "\""
        }
        else {
            params += ",\"categ_code\":null"
        }
        if (goodsId.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"gid\":\"" + goodsId + "\""
        }
        else {
            params += ",\"gid\":null"
        }
        if (transI.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"trans_i\":\"" + transI + "\""
        }
        else {
            params += ",\"trans_i\":null"
        }
        if (nowRec.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"now_rec\":\"" + nowRec + "\""
        }
        else {
            params += ",\"now_rec\":null"
        }
        if (fromRec.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"from_rec\":\"" + fromRec + "\""
        }
        else {
            params += ",\"from_rec\":null"
        }
        if (venGuid.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"ven_guid\":\"" + venGuid + "\""
        }
        else {
            params += ",\"ven_guid\":null"
        }
        if (venSession.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"ven_session\":\"" + venSession + "\""
        }
        else {
            params += ",\"ven_session\":null"
        }
        if (keyword.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"keyword\":\"" + keyword + "\""
        }
        else {
            params += ",\"keyword\":n=ull"
        }
        params += "\"}"
        let Params = params.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        if (Params != nil) {
            params = Params!
        }

        httpPost(url: "https://" + serverLog + apiLog,
                 contentType: "application/x-www-form-urlencoded;charset=UTF-8",
                 postData: params) { (results) in
            if let response = results.response {
                self.Log(msg: "[ven_recomd] httpStatusCode='\(response.httpStatusCode)'")
            }
            if let data = results.data {
                self.Log(msg: "[ven_addCart] data='\(String(decoding: data, as: UTF8.self))'")
            }
        }
    }

    /**
     商品推薦

     :param: recPos p, cap, gop...
     :param: recType AlsoView, ClickStream
     :param: rowItems 推薦數量
     :param: callback callback函數

     */
    func ven_recomd(recPos: String, recType: String, rowItems: Int) -> String {
        Log(msg: "[ven_recomd]" + "venGuid='" + venGuid + "'")
        if check_venGuid() == false {
            venGuid = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=g&pt=a")
            Log(msg: "[ven_recomd] venGuid='\(self.venGuid)'")
        }
        Log(msg: "[ven_recomd] venSession='" + venSession + "'")
        if check_venSession() == false {
            venSession = httpGet(url: "https://" + serverLog + apiUuid + "?id=" + domain + "&typ=s&pt=a")
            Log(msg: "[ven_recomd] venSession='\(self.venSession)'")
        }

        var result = "{}"
        let params = "{\"token\":\"" + token + "\""
                   + ",\"rec_pos\":\"" + recPos + "\""
                   + ",\"rec_type\":\"" + recType + "\""
                   + ",\"device\":\"" + device + "\""
                   + ",\"ven_guid\":\"" + venGuid + "\""
                   + ",\"ven_session\":\"" + venSession + "\""
                   + ",\"topk\":" + String(rowItems)
                   + "}";

        guard let url = URL(string: "https://" + serverHermes + apiHermes) else {
            Log(msg: "[ven_recomd] url error!");
            return result
        }

        guard let httpBody = params.data(using: .utf8) else {
            Log(msg: "[ven_recomd] httpBody error!");
            return result
        }

        var requestHttpHeaders = VenraasptEntity()

        requestHttpHeaders.add(value: "application/json", forKey: "Content-Type")
        requestHttpHeaders.add(value: "application/json", forKey: "Accept")

        guard let request = prepareRequest(withURL: url, requestHttpHeaders: requestHttpHeaders, httpBody: httpBody, httpMethod: .post) else
        {
            return result
        }

        let semaphore = DispatchSemaphore(value: 0)
        let sessionConfiguration = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfiguration)
        let task = session.dataTask(with: request) { (data, response, error) in
            let results = Results(withData: data,
                                  response: Response(fromURLResponse: response),
                                  error: error)
            if let response = results.response {
                self.Log(msg: "[ven_recomd] httpStatusCode='\(response.httpStatusCode)'")
            }
            if let data = results.data {
                result = String(decoding: data, as: UTF8.self)
                self.Log(msg: "[ven_recomd] data='\(result)'\n\n")
                do {
                    // make sure this JSON is in the format we expect
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                        // try to read out a string array
                        if let recomd = json["recomd_id"] as? String {
                            self.Log(msg: "recomd_id='\(recomd)'")
                            self.ven_reccall(_nowRec: recomd)
                        }
                    }
                } catch let error as NSError {
                    Venraaspt.mInstance.Log(msg: "Failed to load: \(error.localizedDescription)")
                }
            }
            semaphore.signal()
        }
        task.resume()
        semaphore.wait()
        self.Log(msg: "[ven_recomd] result='\(result)'\n\n")
        return result
    }

    /**
     webLog for 紀錄推薦方式

     :param: _nowRec 推薦方式代碼

     */
    private func ven_reccall(_nowRec: String) {
        self.nowRec = _nowRec

        let tick: Int64 = Int64((Date().timeIntervalSince1970 * 1000).rounded())
        let zoneOffset = TimeZone.current.secondsFromGMT()
        
        var params = ""
        params = "reccall={"
                + "\"token\":\"" + token + "\""
                + ",\"page_type\":\"" + pageType + "\""
                + ",\"action\":\"reccall\""
                + ",\"client_host\":\"" + clientHost + "\""
                + ",\"tophost\":\"" + topHost + "\""
                + "\",\"device\":\"" + device + "\""
                + ",\"client_utc\":" + String(tick)
                + ",\"client_tzo\":" + String(zoneOffset)

        if (userId.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"uid\":\"" + userId + "\""
        } else {
            params += ",\"uid\":null"
        }
        if (categoryCode.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"categ_code\":\"" + categoryCode + "\""
        } else {
            params += ",\"categ_code\":null"
        }
        if (goodsId.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"gid\":\"" + goodsId + "\""
        } else {
            params += ",\"gid\":null"
        }
        if (transI.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"trans_i\":\"" + transI + "\""
        } else {
            params += ",\"trans_i\":null"
        }
        if (nowRec.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"now_rec\":\"" + nowRec + "\""
        } else {
            params += ",\"now_rec\":null"
        }
        if (fromRec.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"from_rec\":\"" + fromRec + "\""
        } else {
            params += ",\"from_rec\":null"
        }
        if (venGuid.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"ven_guid\":\"" + venGuid + "\""
        } else {
            params += ",\"ven_guid\":null"
        }
        if (venSession.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"ven_session\":\"" + venSession + "\""
        } else {
            params += ",\"ven_session\":null"
        }
        if (keyword.trimmingCharacters(in: .whitespacesAndNewlines).count > 0) {
            params += ",\"keyword\":\"" + keyword + "\""
        } else {
            params += ",\"keyword\":null"
        }
        params += "\"}"
        let Params = params.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        if (Params != nil) {
            params = Params!
        }

        httpPost(url: "https://" + serverLog + apiLog,
                 contentType: "application/x-www-form-urlencoded;charset=UTF-8",
                 postData: params) { (results) in
            if let response = results.response {
                self.Log(msg: "[ven_reccall] httpStatusCode='\(response.httpStatusCode)'")
            }
            if let data = results.data {
                 self.Log(msg: "[ven_reccall] data='\(String(decoding: data, as: UTF8.self))'")
            }
        }
    }

    func Log(msg: String) {
        let date = Date()
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd HH:mm:ss.SSSS"
        print("\(df.string(from: date)) \(msg)");
    }


    //private function
    private func ven_clear() {
        self.action = ""
        self.pageType = ""
        self.categoryCode = ""
        self.goodsId = ""
        self.transI = ""
        self.nowRec = ""
        self.fromRec = ""
        self.keyword = ""
    }

    private func check_venGuid() -> Bool {
        Log(msg: "[check_venGuid] venGuid='\(venGuid)'")
        for i in 0..<10 {
            if venGuid.trimmingCharacters(in: .whitespacesAndNewlines).count == 0 {
                Thread.sleep(forTimeInterval: 100)
                Log(msg: "[check_venSession][\(i)]")
            }
            else {
                return true
            }
        }
        return false
    }

    private func check_venSession() -> Bool {
        Log(msg: "[check_venSession] venSession='\(venSession)'")
        for i in 0..<10 {
            if (venSession.trimmingCharacters(in: .whitespacesAndNewlines).count == 0) {
                Thread.sleep(forTimeInterval: 100)
                Log(msg: "[check_venSession] [\(i)]")
            }
            else {
                return true
            }
        }
        return false
    }


    // MARK: - Public Methods for RESTFUL API
    func httpGet(url: String) -> String {
        Log(msg: "[httpGet] url='\(url)'")

        guard let url = URL(string: url) else {
            Log(msg: "[httpGet] url error!");
            return ""
        }

        let requestHttpHeaders = VenraasptEntity()
        let httpBody: Data? = nil

        guard let request = self.prepareRequest(withURL: url, requestHttpHeaders: requestHttpHeaders, httpBody: httpBody, httpMethod: .get) else
        {
            //callback(Results(withError: CustomError.failedToCreateRequest))
            return ""
        }

        var result = ""
        let semaphore = DispatchSemaphore(value: 0)
        let sessionConfiguration = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfiguration)
        let task = session.dataTask(with: request) { (data, response, error) in
            if let error = error {
                self.Log(msg: "error: \(error)")
            } else {
                if let response = response as? HTTPURLResponse {
                    self.Log(msg: "statusCode: \(response.statusCode)")
                }
                if let data = data, let dataString = String(data: data, encoding: .utf8) {
                    self.Log(msg: "data: \(dataString)")
                    result = dataString
                }
            }
            semaphore.signal()
        }
        task.resume()
        semaphore.wait()
        return result
    }

    func httpPost(url: String, contentType: String, postData: String, callback: @escaping (_ results: Results) -> Void) {
        Log(msg: "[httpPost] url='\(url)'\n postData='\(postData)'")

        guard let url = URL(string: url) else {
            Log(msg: "[httpGet] url error!");
            return
        }

        guard let httpBody = postData.data(using: .utf8) else {
            Log(msg: "[httpPost] httpBody error!");
            return
        }

        var requestHttpHeaders = VenraasptEntity()

        requestHttpHeaders.add(value: contentType, forKey: "Content-Type")

        DispatchQueue.global(qos: .background).async { [weak self] in
            Venraaspt.mInstance.Log(msg: "[httpPost] DispatchQueue");

            guard let request = self?.prepareRequest(withURL: url, requestHttpHeaders: requestHttpHeaders, httpBody: httpBody, httpMethod: .post) else
            {
                callback(Results(withError: CustomError.failedToCreateRequest))
                return
            }

            let sessionConfiguration = URLSessionConfiguration.default
            let session = URLSession(configuration: sessionConfiguration)
            let task = session.dataTask(with: request) { (data, response, error) in
                callback(Results(withData: data,
                                   response: Response(fromURLResponse: response),
                                   error: error))
            }
            task.resume()
        }
    }

    // MARK: - Private Methods for RESTFUL API
    private func addURLQueryParameters(toURL url: URL, urlQueryParameters: VenraasptEntity) -> URL {
        if urlQueryParameters.totalItems() > 0 {
            guard var urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return url }
            var queryItems = [URLQueryItem]()
            for (key, value) in urlQueryParameters.allValues() {
                let item = URLQueryItem(name: key, value: value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed))

                queryItems.append(item)
            }

            urlComponents.queryItems = queryItems

            guard let updatedURL = urlComponents.url else { return url }
            return updatedURL
        }

        return url
    }


    private func getHttpBody(requestHttpHeaders: VenraasptEntity, httpBodyParameters: VenraasptEntity, httpBody: Data?) -> Data? {
        guard let contentType = requestHttpHeaders.value(forKey: "Content-Type") else { return nil }

        if contentType.contains("application/json") {
            return try? JSONSerialization.data(withJSONObject: httpBodyParameters.allValues(), options: [.prettyPrinted, .sortedKeys])
        } else if contentType.contains("application/x-www-form-urlencoded") {
            let bodyString = httpBodyParameters.allValues().map { "\($0)=\(String(describing: $1.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)))" }.joined(separator: "&")
            return bodyString.data(using: .utf8)
        } else {
            return httpBody
        }
    }


    private func prepareRequest(withURL url: URL?, requestHttpHeaders: VenraasptEntity, httpBody: Data?, httpMethod: HttpMethod) -> URLRequest? {
        guard let url = url else { return nil }
        var request = URLRequest(url: url)
        request.httpMethod = httpMethod.rawValue
        
        for (header, value) in requestHttpHeaders.allValues() {
            request.setValue(value, forHTTPHeaderField: header)
        }

        request.httpBody = httpBody
        return request
    }

}

// MARK: - Venraaspt Custom Types
extension Venraaspt {
    enum HttpMethod: String {
        case get
        case post
        case put
        case patch
        case delete
    }


    struct VenraasptEntity {
        private var values: [String: String] = [:]

        mutating func add(value: String, forKey key: String) {
            values[key] = value
        }

        func value(forKey key: String) -> String? {
            return values[key]
        }

        func allValues() -> [String: String] {
            return values
        }

        func totalItems() -> Int {
            return values.count
        }
    }


    struct Response {
        var response: URLResponse?
        var httpStatusCode: Int = 0
        var headers = VenraasptEntity()

        init(fromURLResponse response: URLResponse?) {
            guard let response = response else { return }
            self.response = response
            httpStatusCode = (response as? HTTPURLResponse)?.statusCode ?? 0

            if let headerFields = (response as? HTTPURLResponse)?.allHeaderFields {
                for (key, value) in headerFields {
                    headers.add(value: "\(value)", forKey: "\(key)")
                }
            }
        }
    }


    struct Results {
        var data: Data?
        var response: Response?
        var error: Error?

        init(withData data: Data?, response: Response?, error: Error?) {
            self.data = data
            self.response = response
            self.error = error
        }

        init(withError error: Error) {
            self.error = error
        }
    }


    enum CustomError: Error {
        case failedToCreateRequest
    }
}


// MARK: - Custom Error Description
extension Venraaspt.CustomError: LocalizedError {
    public var localizedDescription: String {
        switch self {
        case .failedToCreateRequest: return NSLocalizedString("Unable to create the URLRequest object", comment: "")
        }
    }
}
