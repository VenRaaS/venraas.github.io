//
//  ContentView.swift
//  venraas
//
//  Created by 廖文全 on 2019/11/22.
//  Copyright © 2019 廖文全. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var result: String

    var body: some View {
        Text(verbatim: result)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(result: Venraaspt.mInstance.venSession)
    }
}
