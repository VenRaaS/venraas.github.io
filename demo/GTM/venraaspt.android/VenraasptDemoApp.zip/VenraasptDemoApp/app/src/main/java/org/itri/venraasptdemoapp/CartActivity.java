package org.itri.venraasptdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import org.itri.venraaspt.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class CartActivity extends AppCompatActivity {
    private Button buttonPortal;
    private Button buttonEdm;
    private Button buttonSearch;
    private Button buttonCheckout;

    private JSONArray jGoods;
    private String recomd_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        buttonPortal = findViewById(R.id.buttonPortal);
        buttonPortal.setOnClickListener(portal);
        buttonEdm = findViewById(R.id.buttonEDM);
        buttonEdm.setOnClickListener(edm);
        buttonSearch = findViewById(R.id.buttonSearch);
        buttonSearch.setOnClickListener(search);
        buttonCheckout = findViewById(R.id.buttonCheckout);
        buttonCheckout.setOnClickListener(checkout);

        //webLog for cart(購物車頁) @param transI 購物車資訊
        String transI = "{\"id\":null,\"ilist\":[";
        String ref_info = "[";
        for (int i=0; i<MyApplication.getInstance().orderList.size(); i++) {
            if (i > 0) {
                transI += ",";
                ref_info += ",";
            }
            transI += "{\"id\":\"" + MyApplication.getInstance().orderList.get(i) + "\"}";
            ref_info += "{\"gid\":\"" + MyApplication.getInstance().orderList.get(i) + "\"}";
        }
        transI += "]}";
        ref_info += "]";
        MyApplication.getInstance().transI = transI;
        Venraaspt.getInstance().ven_refInfo(ref_info);
        Venraaspt.getInstance().ven_cart(MyApplication.getInstance().transI);

        //商品推薦Callback函數
        VenraasptCallback callback = new VenraasptCallback() {
            @Override
            public void recomdCallback(String result) {
                try {
                    JSONObject jObj = new JSONObject(result);
                    recomd_id = jObj.getString("recomd_id");
                    jGoods = jObj.getJSONArray("recomd_list");
                    Log.i("JSONObject", "recomd_list size=" + jGoods.length());
                    for (int i=0; i<jGoods.length(); i++) {
                        JSONObject obj = jGoods.getJSONObject(i);
//                        showImage(i + 1, obj.getString("goods_img_url").replaceAll("http://", "https://"));
                    }
                } catch(Exception e) {
                    Log.i("JSONObject", e.toString());
                }
            }
        };

        //商品推薦
        Venraaspt.getInstance().ven_recomd("scp", "ClickStream", 10, callback);
    }

    private View.OnClickListener portal = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
    };

    private View.OnClickListener edm = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), EdmActivity.class));
        }
    };

    private View.OnClickListener search = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            MyApplication.getInstance().keyword = "iPhone";
            startActivity(new Intent(getApplicationContext(), SearchActivity.class));
        }
    };

    private View.OnClickListener checkout = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), CheckoutActivity.class));
        }
    };
}
