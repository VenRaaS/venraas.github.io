package org.itri.venraasptdemoapp;

import android.app.Application;
import android.content.SharedPreferences;
import android.util.Log;

import org.itri.venraaspt.*;

import java.util.ArrayList;

public class MyApplication extends Application {
    private static MyApplication mInstance;

    //add for venraaspt
    public String name;
    public String categoryCode;
    public String goodsId;
    public String transI;
    public String nowRec;
    public String fromRec;
    public String keyword;

    public ArrayList<String> orderList_name = new ArrayList();
    public ArrayList<String> orderList_gid = new ArrayList();
    public ArrayList<String> orderList_cid = new ArrayList();

    public static synchronized MyApplication getInstance() {
        return mInstance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

        Log.i("[MyApplication]", "initial venraaspt");
        String venGuid = null;
        SharedPreferences pref = getApplicationContext().getSharedPreferences("org.itri.venraaspt", MODE_PRIVATE);
        if (pref != null) {
            venGuid = pref.getString("venGuid", null);
            Log.i("[MyApplication]", "found venGuid=" + venGuid);
        }
        else {
            Log.i("[MyApplication]", "pref is null");
        }

        //ven_init : 初始化venraaspt
        Venraaspt.getInstance().ven_init(
                "apid.venraas.tw",
                "apih.venraas.tw",
                "xVtZLw5p4n",
                "venraas.github.io",
                "venraas.github.io",
                "venraas.github.io",
                venGuid);

        //設定uid(user id)
        Venraaspt.getInstance().ven_uid("venraaspt.android");

        if (venGuid == null) {
            Log.i("[MyApplication]", "venGuid=" + Venraaspt.getInstance().getVenGuid());

            SharedPreferences.Editor editor = pref.edit();
            editor.putString("venGuid", Venraaspt.getInstance().getVenGuid());
            editor.commit();
        }
    }
}
