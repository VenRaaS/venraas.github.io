package org.itri.venraasptdemoapp;

import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.appcompat.app.AppCompatActivity;

import org.itri.venraaspt.*;

public class JavaScriptInterface {
    protected AppCompatActivity parentActivity;
    protected WebView webView;

    private String uid;

    public JavaScriptInterface(WebView webView)  {
        this.webView = webView;
    }

    @JavascriptInterface
    public void setUid(String val) {
        Log.d("[JavaScriptInterface]", "setUid(" + val + ")");
        this.uid = val;
        Venraaspt.getInstance().ven_uid(val);
    }
}
