package org.itri.venraasptdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import org.json.JSONArray;
import org.json.JSONObject;

import org.itri.venraaspt.*;

import java.io.InputStream;
import java.net.URL;

public class GoodsActivity extends AppCompatActivity {
    private Button buttonPortal;
    private Button buttonEdm;
    private Button buttonSearch;
    private Button buttonCategory;
    private Button buttonCart;
    private Button buttonAddCart;

    private JSONArray jGoods;
    private String recomd_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i("[GoodsActivity]", "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods);

        buttonPortal = findViewById(R.id.buttonPortal);
        buttonPortal.setOnClickListener(portal);
        buttonEdm = findViewById(R.id.buttonEDM);
        buttonEdm.setOnClickListener(edm);
        buttonSearch = findViewById(R.id.buttonSearch);
        buttonSearch.setOnClickListener(search);
        buttonCategory = findViewById(R.id.buttonCategory);
        buttonCategory.setOnClickListener(category);
        buttonCart = findViewById(R.id.buttonCart);
        buttonCart.setOnClickListener(cart);
        buttonAddCart = findViewById(R.id.buttonAddCart);
        buttonAddCart.setOnClickListener(addcart);

        //webLog for goods(商品頁)
        //@param categoryCode 分類頁代碼
        //@param goodsId 商品代碼
        //@param keyword 搜尋字串
        //@param fromRec 來源推薦方式代碼
        Venraaspt.getInstance().ven_goods(
                MyApplication.getInstance().categoryCode,
                MyApplication.getInstance().goodsId,
                MyApplication.getInstance().keyword,
                MyApplication.getInstance().fromRec);

        JSONObject jObj = Venraaspt.getInstance().jGoods;
        if (jObj != null) {
            try {
                final String url = jObj.getString("goods_img_url").replaceAll("http://", "https://");
                Log.i("showImage", "url=" + url);
                try {
                    ImageView image = findViewById(R.id.image);
                    new DownloadImageTask(image).execute(url);
                } catch (Exception e) {
                    Log.i("showImage", e.toString());
                }
            } catch(Exception e) {
                Log.i("JSONObject", e.toString());
            }
        }

        //商品推薦Callback函數
        VenraasptCallback callback = new VenraasptCallback() {
            @Override
            public void recomdCallback(String result) {
                try {
                    JSONObject jObj = new JSONObject(result);
                    recomd_id = jObj.getString("recomd_id");
                    jGoods = jObj.getJSONArray("recomd_list");
                    Log.i("JSONObject", "recomd_list size=" + jGoods.length());
                    for (int i=0; i<jGoods.length(); i++) {
                        JSONObject obj = jGoods.getJSONObject(i);
                        showImage(i + 1, obj.getString("goods_img_url").replaceAll("http://", "https://"));
                    }
                } catch(Exception e) {
                    Log.i("JSONObject", e.toString());
                }
            }
        };

        //商品推薦
        Venraaspt.getInstance().ven_recomd("gop", "AlsoView", 10, callback);
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;
        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap bmp = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                bmp = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("[doInBackground]", e.getMessage());
                e.printStackTrace();
            }
            return bmp;
        }
        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

    private void showImage(int idx, String url) {
        Log.i("showImage", "url=" + url);
        String imageID = "image" + idx;
        int resID = getResources().getIdentifier(imageID, "id", getPackageName());
        ImageView image = findViewById(resID);
        try {
            InputStream is = (InputStream) new URL(url).getContent();
            Drawable draw = Drawable.createFromStream(is, "src");
            image.setImageDrawable(draw);
        } catch (Exception e) {
            Log.i("showImage", e.toString());
        }
    }

    public void imageClick(View v) {
        int idx = 0;
        switch(v.getId()) {
            case R.id.image1:
                idx = 0;
                break;
            case R.id.image2:
                idx = 1;
                break;
            case R.id.image3:
                idx = 2;
                break;
            case R.id.image4:
                idx = 3;
                break;
            case R.id.image5:
                idx = 4;
                break;
            case R.id.image6:
                idx = 5;
                break;
            case R.id.image7:
                idx = 6;
                break;
            case R.id.image8:
                idx = 7;
                break;
            case R.id.image9:
                idx = 8;
                break;
            case R.id.image10:
                idx = 9;
                break;
        }
        Log.v("imageClick", "idx=" + idx);

        try {
            JSONObject obj = jGoods.getJSONObject(idx);
            String cid = obj.getString("category_code");
            String gid = obj.getString("id");
            if ((cid != null) && (cid.trim().length() > 0)) {
                MyApplication.getInstance().categoryCode = cid;
            }
            else {
                String[] gids = gid.split("-");
                MyApplication.getInstance().categoryCode = gids[0];
            }
            MyApplication.getInstance().goodsId = gid;
            MyApplication.getInstance().fromRec = recomd_id;
            MyApplication.getInstance().nowRec = null;
            Venraaspt.getInstance().jGoods = obj;
            startActivity(new Intent(getApplicationContext(), GoodsActivity.class));
        } catch (Exception e) {
            Log.i("imageClick", "idx=" + idx + ", " + e.toString());
        }
    };

    private View.OnClickListener portal = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
    };

    private View.OnClickListener edm = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), EdmActivity.class));
        }
    };

    private View.OnClickListener search = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            MyApplication.getInstance().keyword = "iPhone";
            startActivity(new Intent(getApplicationContext(), SearchActivity.class));
        }
    };

    private View.OnClickListener category = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), CategoryActivity.class));
        }
    };

    private View.OnClickListener cart = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(), CartActivity.class));
        }
    };

    private View.OnClickListener addcart = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //webLog for 商品放入購物車時呼叫 @param _goodsId 商品代碼
            MyApplication.getInstance().orderList.add(MyApplication.getInstance().goodsId);
            Venraaspt.getInstance().ven_cartAdd(MyApplication.getInstance().goodsId);
        }
    };
}
