package org.itri.venraasptdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.itri.venraaspt.*;

public class CheckoutActivity extends AppCompatActivity {
    private JavaScriptInterface jsInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        String venGuid = Venraaspt.getInstance().getVenGuid();
        String venSession = Venraaspt.getInstance().getVenSession();

        WebView webview = findViewById(R.id.webviewCheckout);
        WebSettings webSettings = webview.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.contains("Android.MainActivity")) {
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    return true;
                }
                else if (url.contains("Android.EdmActivity")) {
                    startActivity(new Intent(getApplicationContext(), EdmActivity.class));
                    return true;
                }
                else if (url.contains("Android.SearchActivity")) {
                    startActivity(new Intent(getApplicationContext(), SearchActivity.class));
                    return true;
                }
                else {
                    return false;
                }
            }
        });
        CookieManager.setAcceptFileSchemeCookies(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.setAcceptFileSchemeCookies(true);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeAllCookies(null);
        cookieManager.setAcceptCookie(true);
        cookieManager.removeSessionCookies(null);
        cookieManager.setCookie("venraas.github.io", "vensession=" + venSession);
        cookieManager.setCookie("venraas.github.io", "venguid=" + venGuid);
        CookieManager.getInstance().flush();
        Log.d("cookie", cookieManager.getCookie("venraas.github.io"));

        //
        jsInterface = new JavaScriptInterface(webview);
        webview.addJavascriptInterface(jsInterface, "Android");

        String url = "https://venraas.github.io/demo/GTM/checkout_android.html";
        url += "?venguid=" + venGuid
            + "&vensession=" + venSession
            + "&amount=1&total=1234";
        webview.loadUrl(url);

        WebChromeClient wbc = new WebChromeClient() {
            public void onCloseWindow(WebView w){
                Log.d("WebChromeClient", "Window trying to close");
            }
        };
        webview.setWebChromeClient(wbc);
    }
}
