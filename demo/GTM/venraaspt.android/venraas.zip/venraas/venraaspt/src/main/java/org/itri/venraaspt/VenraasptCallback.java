package org.itri.venraaspt;

public interface VenraasptCallback {
    public void recomdCallback(String result);
}
