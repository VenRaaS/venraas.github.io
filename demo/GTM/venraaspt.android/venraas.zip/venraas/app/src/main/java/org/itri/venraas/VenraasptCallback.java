package org.itri.venraas;

public interface VenraasptCallback {
    public void recomdCallback(String result);
}
