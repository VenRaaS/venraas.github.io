package org.itri.venraas;

import android.app.Application;
import android.util.Log;

import org.itri.venraaspt.*;

public class MyApplication extends Application {
    private static MyApplication mInstance;

    //add for venraaspt
    public String categoryCode;
    public String goodsId;
    public String transI;
    public String nowRec;
    public String fromRec;
    public String keyword;

    public static synchronized MyApplication getInstance() {
        return mInstance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

        Log.i("[MyApplication]", "initial venraaspt");
        //Venraaspt.getInstance().ven_init("apid.venraas.tw", "apih.venraas.tw", "5guOvNnKn2", "venraas.github.io", "venraas.github.io", "venraas.github.io");
        Venraaspt.getInstance().ven_init("apid.friday.tw", "apih.friday.tw", "9Rs7ZrElXm", "venraas.github.io", "venraas.github.io", "venraas.github.io");
        Venraaspt.getInstance().ven_uid("12345678");
    }
}
